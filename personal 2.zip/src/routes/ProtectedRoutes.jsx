export const ProtectedRoutes = ({ children }) => {
  return children;
};
