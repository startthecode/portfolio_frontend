import { useLocation } from "react-router-dom";

const usePageTitle = ({ pagetitle }) => {
  let location = useLocation();

 



  return <div></div>;
};
