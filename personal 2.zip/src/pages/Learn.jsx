export const Learn = () => {
  return <div></div>;
};
